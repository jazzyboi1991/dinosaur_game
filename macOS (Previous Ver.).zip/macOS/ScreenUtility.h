#ifndef SCREENUTILITY_H
#define SCREENUTILITY_H

#pragma once
class ScreenUtility
{
public:
    static void CursorSettings();
    static void SetCursor(int x, int y);
    static void Clear();
};

#endif