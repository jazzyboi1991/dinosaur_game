#ifndef SCREENUTILITY_H_
#define SCREENUTILITY_H_

#pragma once

class ScreenUtility
{
public:
    static void CursorSettings();
    static void SetCursor(int x, int y);
    static void Clear();
};

#endif