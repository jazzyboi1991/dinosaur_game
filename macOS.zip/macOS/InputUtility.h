#ifndef INPUTUTILITY_H_
#define INPUTUTILITY_H_

#pragma once

int GetKeyDown();

#endif